package edu.floridapoly.take32;

public class User {
    int id;
    String firstName;
    String lastName;
    String year;
    String major;
    String course;




}
